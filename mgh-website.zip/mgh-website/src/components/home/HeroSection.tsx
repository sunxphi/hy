
import React from 'react';
import styles from './HeroSection.module.css';

export default function HeroSection() {
  return (
    <section className={styles.hero}>
      <div className={styles.content}>
        <h1 className={styles.title}>Discover Your Hawaiian Adventure</h1>
        <p className={styles.subtitle}>Experience the beauty of Hawaii like never before.</p>
        <button className={styles.cta}>Book Now</button>
      </div>
    </section>
                    