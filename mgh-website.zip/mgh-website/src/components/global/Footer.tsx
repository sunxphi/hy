
import React from 'react';
import styles from './Footer.module.css';

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.section}>
          <h2 className={styles.title}>Quick Links</h2>
          <ul className={styles.list}>
            <li><a href="/experiences" className={styles.link}>Experiences</a></li>
            <li><a href="/destinations" className={styles.link}>Destinations</a></li>
            <li><a href="/about" className={styles.link}>About Us</a></li>
            <li><a href="/contact" className={styles.link}>Contact</a></li>
          </ul>
        </div>
        <div className={styles.section}>
          <h2 className={styles.title}>Contact Us</h2>
          <p>Email: info@mgh.com</p>
          <p>Phone: (808) 123-4567</p>
        </div>
        <div className={styles.section}>
          <h2 className={styles.title}>Follow Us</h2>
          <div className={styles.social}>
            <a href="https://www.instagram.com/mgh" className={styles.socialLink}>Instagram</a>
            <a href="https://www.facebook.com/mgh" className={styles.socialLink}>Facebook</a>
          </div>
        </div>
      </div>
      <div className={styles.newsletter}>
        <h2 className={styles.title}>Stay Updated</h2>
        <form className={styles.form}>
          <input type="email" placeholder="Your email address" className={styles.input} />
          <button type="submit" className={styles.button}>Subscribe</button>
        </form>
      </div>
    </footer>
                    