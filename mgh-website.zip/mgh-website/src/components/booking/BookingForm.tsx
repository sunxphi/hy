
import React from 'react';
import { useForm } from 'react-hook-form';
import styles from './BookingForm.module.css';

interface BookingFormProps {
  onSubmit: (data: any) => void;
}

export default function BookingForm({ onSubmit }: BookingFormProps) {
  const { register, handleSubmit, errors } = useForm();

  return (
    <form onSubmit={handleSubmit(onSubmit)} className={styles.form}>
      <div className={styles.formGroup}>
        <label htmlFor="name" className={styles.label}>
          Name
        </label>
        <input
          id="name"
          name="name"
          ref={register({ required: true })}
          className={styles.input}
        />
        {errors.name && <p className={styles.error}>Name is required</p>}
      </div>
      <div className={styles.formGroup}>
        <label htmlFor="email" className={styles.label}>
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          ref={register({ required: true })}
          className={styles.input}
        />
        {errors.email && <p className={styles.error}>Email is required</p>}
      </div>
      <div className={styles.formGroup}>
        <label htmlFor="date" className={styles.label}>
          Date
        </label>
        <input
          id="date"
          name="date"
          type="date"
          ref={register({ required: true })}
          className={styles.input}
        />
        {errors.date && <p className={styles.error}>Date is required</p>}
      </div>
      <div className={styles.formGroup}>
        <label htmlFor="experience" className={styles.label}>
          Experience
        </label>
        <select
          id="experience"
          name="experience"
          ref={register({ required: true })}
          className={styles.select}
        >
          <option value="">Select an experience</option>
          <option value="hiking">Hiking</option>
          <option value="snorkeling">Snorkeling</option>
        </select>
        {errors.experience && <p className={styles.error}>Experience is required</p>}
      </div>
      <button type="submit" className={styles.button}>
        Book Now
      </button>
    </form>
                    