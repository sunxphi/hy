
import React from 'react';
import { Seo } from '@shopify/hydrogen';
import Header from './Header';
import Footer from './Footer';
import styles from './Layout.module.css';

interface LayoutProps {
  children: React.ReactNode;
  title?: string;
}

export default function Layout({ children, title }: LayoutProps) {
  return (
    <div className={styles.container}>
      <Seo type="defaultSeo" data={{ title }} />
      <Header />
      <main className={styles.main}>{children}</main>
      <Footer />
    </div>
  );
}
                    