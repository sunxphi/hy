
import React, { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import styles from './InteractiveMap.module.css';

mapboxgl.accessToken = 'YOUR_MAPBOX_ACCESS_TOKEN';

export default function InteractiveMap() {
  const mapContainer = useRef(null);
  const map = useRef(null);

  useEffect(() => {
    if (map.current) return;
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [-157.858, 21.315],
      zoom: 9
    });

    // Add markers for experiences
    new mapboxgl.Marker()
      .setLngLat([-157.858, 21.315])
      .setPopup(new mapboxgl.Popup().setHTML("<h3>Experience Title</h3><p>Description</p>"))
      .addTo(map.current);
  }, []);

  return <div ref={mapContainer} className={styles.mapContainer} />;
                    