
import React from 'react';
import { Link } from '@shopify/hydrogen';
import styles from './Header.module.css';

export default function Header() {
  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link to="/" className={styles.logo}>MGH</Link>
        <nav className={styles.nav}>
          <Link to="/experiences" className={styles.navItem}>Experiences</Link>
          <Link to="/destinations" className={styles.navItem}>Destinations</Link>
          <Link to="/about" className={styles.navItem}>About Us</Link>
          <Link to="/contact" className={styles.navItem}>Contact</Link>
        </nav>
      </div>
    </header>
                    