
import React from 'react';
import { Image, Money } from '@shopify/hydrogen';
import { Product } from '@shopify/hydrogen/storefront-api-types';
import styles from './ExperienceCard.module.css';

interface ExperienceCardProps {
  experience: Product;
}

export default function ExperienceCard({ experience }: ExperienceCardProps) {
  const { title, featuredImage, priceRange } = experience;

  return (
    <div className={styles.card}>
      {featuredImage && (
        <Image
          data={featuredImage}
          className={styles.image}
          width={300}
          height={200}
        />
      )}
      <div className={styles.content}>
        <h3 className={styles.title}>{title}</h3>
        <p className={styles.description}>
          {experience.description?.substring(0, 100)}...
        </p>
        <div className={styles.footer}>
          <Money data={priceRange.minVariantPrice} />
          <button className={styles.button}>Book Now</button>
        </div>
      </div>
    </div>
                    